import cv2
import numpy as np
import image_preparation as img
import zigzag as zz

def analyze_lsb_distribution(image_path):
    image = cv2.imread(image_path, cv2.IMREAD_COLOR)
    image_f32 = np.float32(image)
    image_YCC = img.YCC_Image(cv2.cvtColor(image_f32, cv2.COLOR_BGR2YCrCb))
    
    # Tính DCT nhưng KHÔNG lượng tử hóa
    dct_blocks = [cv2.dct(block) for block in image_YCC.channels[0]]  # analyze Y
    sorted_coeffs = [zz.zigzag(block) for block in dct_blocks]  # zigzag
    
    # Count bit LSB
    lsb_counts = {'0': 0, '1': 0}
    total_coeffs = 0
    for block in sorted_coeffs:
        for coeff in block[1:]:
            if abs(coeff) > 1:
                lsb = int(coeff) & 1
                lsb_counts[str(lsb)] += 1
                total_coeffs += 1
    
    total = lsb_counts['0'] + lsb_counts['1']
    ratio = lsb_counts['1'] / total if total > 0 else 0
    
    # debug
    # print(f"Image: {image_path}")
    # print(f"LSB counts: {lsb_counts}")
    # print(f"Total coefficients analyzed: {total_coeffs}")
    # print(f"Ratio of 1s: {ratio:.3f}")
    
    return "Stego" if 0.45 <= ratio <= 0.55 else "Clean"

with open("analyze_result.txt", "w") as f:
    result1 = analyze_lsb_distribution("mountain.png")
    result2 = analyze_lsb_distribution("stego_image.png")
    f.write(f"mountain.png: {result1}\n")
    f.write(f"stego_image.png: {result2}\n")